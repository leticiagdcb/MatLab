# Projeto_VLC_ACO-OFDM
Comunicação por luz visível (VLC):Análise e síntese por simulação utilizando o MATLAB. Autores: Gabrielle Cristina de Souza Silva &amp; Leonardo Alexandre da Silva
